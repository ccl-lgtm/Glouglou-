# GLOUGLOU — générer l'APK avec Capacitor

Ce dossier contient le jeu (`www/index.html`) prêt à être empaqueté en application Android via **Capacitor**.

## Option B — build dans le cloud, sans rien installer (GitHub Actions)

Si tu ne veux pas installer Android Studio, ce dépôt contient déjà un workflow
(`.github/workflows/build-apk.yml`) qui compile l'APK sur les serveurs GitHub.

1. Crée un dépôt sur https://github.com et pousse-y tout ce dossier :
   ```bash
   cd glouglou-app
   git init && git add . && git commit -m "GLOUGLOU"
   git branch -M main
   git remote add origin https://github.com/TON_PSEUDO/glouglou.git
   git push -u origin main
   ```
2. Sur GitHub, onglet **Actions** : le build se lance tout seul (ou clique **Run workflow**).
3. À la fin, ouvre le job → section **Artifacts** → télécharge **glouglou-debug-apk**.
   Tu obtiens `app-debug.apk`, prêt à installer.

Aucun SDK ni Gradle à installer chez toi : tout se passe côté serveur.

## Option C — services no-code (le plus rapide)

Tu peux aussi uploader `www/index.html` (ou le zip) dans un emballeur web→APK :
Median.co, WebIntoApp, ou Appilix. Tu colles le fichier, ils génèrent l'APK.
Moins flexible, mais zéro ligne de commande.

## Prérequis (à installer une fois)

- **Node.js** (version LTS) — https://nodejs.org
- **Android Studio** — https://developer.android.com/studio
  - Au premier lancement, laisse-le installer le **Android SDK** et un **JDK** (inclus).
  - Ouvre une fois Android Studio pour qu'il finisse sa configuration.

## Générer l'APK (étapes)

Depuis un terminal, dans ce dossier `glouglou-app/` :

```bash
# 1. installer les dépendances
npm install

# 2. ajouter la plateforme Android (crée le dossier android/)
npx cap add android

# 3. copier le contenu de www/ dans le projet natif
npx cap sync

# 4. ouvrir le projet dans Android Studio
npx cap open android
```

Dans **Android Studio** :
1. Attends la fin de la synchronisation Gradle (barre de progression en bas).
2. Menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
3. L'APK est généré ici :
   `android/app/build/outputs/apk/debug/app-debug.apk`
4. Transfère ce fichier sur ton téléphone et installe-le (autoriser « sources inconnues »).

### Alternative 100 % ligne de commande

```bash
npx cap sync android
cd android
./gradlew assembleDebug      # Windows : gradlew.bat assembleDebug
```
Même chemin de sortie pour l'APK.

## APK signé (pour le Play Store / distribution)

L'APK `debug` ci-dessus sert aux tests. Pour une version publiable :
- Dans Android Studio : **Build → Generate Signed Bundle / APK**, crée une clé (keystore) et suis l'assistant.
- Garde précieusement le keystore : il sera exigé pour toute mise à jour.

## Polices hors-ligne (recommandé)

Le jeu charge les polices **Unbounded** et **Manrope** depuis Google Fonts. Une **police système de secours** est déjà en place, donc l'app reste lisible sans connexion — mais pour le rendu exact hors-ligne, bundle les polices :

1. Récupère les fichiers `.woff2` (par ex. via https://gwfh.mranftl.com) :
   - Unbounded : graisses 500, 700, 900
   - Manrope : graisses 500, 700, 800
2. Place-les dans `www/fonts/`.
3. Dans `www/index.html`, **supprime** la balise `<link ... fonts.googleapis.com ...>` et **ajoute** dans le `<style>` :

```css
@font-face{font-family:"Unbounded";src:url("fonts/unbounded-500.woff2") format("woff2");font-weight:500;font-display:swap}
@font-face{font-family:"Unbounded";src:url("fonts/unbounded-700.woff2") format("woff2");font-weight:700;font-display:swap}
@font-face{font-family:"Unbounded";src:url("fonts/unbounded-900.woff2") format("woff2");font-weight:900;font-display:swap}
@font-face{font-family:"Manrope";src:url("fonts/manrope-500.woff2") format("woff2");font-weight:500;font-display:swap}
@font-face{font-family:"Manrope";src:url("fonts/manrope-700.woff2") format("woff2");font-weight:700;font-display:swap}
@font-face{font-family:"Manrope";src:url("fonts/manrope-800.woff2") format("woff2");font-weight:800;font-display:swap}
```
4. Relance `npx cap sync`.

## Personnalisation

- **Nom de l'app** : champ `appName` dans `capacitor.config.json`.
- **Identifiant** : champ `appId` (forme `com.tonnom.glouglou`) — à fixer avant publication.
- **Icône / splash** : `npm install @capacitor/assets`, place une image 1024×1024 dans `assets/`, puis `npx capacitor-assets generate`.

## Bon à savoir

- La **persistance** (langue, prénoms, mode) fonctionne dans l'app : le WebView gère `localStorage`.
- Toute modif du jeu se fait dans `www/index.html`, suivie de `npx cap sync` pour la répercuter dans l'APK.
